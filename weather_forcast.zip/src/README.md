# weather-forecast
Fetch API collaboration project to get the current forecast
